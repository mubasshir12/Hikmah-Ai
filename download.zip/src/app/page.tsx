
"use client";

import ChatPageClient from "@/components/hikmah/ChatPageClient";
// No need for useAuth, useRouter, useEffect, Loader2 here anymore
// as the main page is no longer protected by default.

export default function Home() {
  // The ChatPageClient can now be rendered directly.
  return <ChatPageClient />;
}
