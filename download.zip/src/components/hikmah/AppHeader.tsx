
"use client";
import { Button } from '@/components/ui/button';
import { Moon, Sun, Sparkles, Loader2, Search, Copy, Volume2, Check } from 'lucide-react'; 
import { useState, useEffect, useRef } from 'react';
import { getGeneralDua } from '@/ai/flows/general-dua-flow';
import { duaSuggestion } from '@/ai/flows/dua-suggestion';
import type { DuaSuggestionOutput } from '@/ai/schemas/dua-suggestion-schemas';
import { Skeleton } from "@/components/ui/skeleton";

import {
  AlertDialog,
  AlertDialogContent,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogFooter,
  AlertDialogAction,
} from "@/components/ui/alert-dialog";
import { Textarea } from '@/components/ui/textarea';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const DuaContentSkeleton = () => {
  return (
    <div className="space-y-3 animate-pulse py-2">
      <Skeleton className="h-24 md:h-28 w-full rounded-md bg-muted/40 dark:bg-muted/20" />
      <div className="space-y-2 rounded-md p-3 bg-muted/20 dark:bg-muted/10">
        <Skeleton className="h-4 w-1/3 rounded-sm bg-muted/30 dark:bg-muted/15" />
        <Skeleton className="h-4 w-full rounded-sm bg-muted/30 dark:bg-muted/15" />
        <Skeleton className="h-4 w-4/5 rounded-sm bg-muted/30 dark:bg-muted/15" />
      </div>
      <div className="space-y-2 rounded-md p-3 bg-muted/20 dark:bg-muted/10">
        <Skeleton className="h-4 w-1/4 rounded-sm bg-muted/30 dark:bg-muted/15" />
        <Skeleton className="h-4 w-full rounded-sm bg-muted/30 dark:bg-muted/15" />
        <Skeleton className="h-4 w-5/6 rounded-sm bg-muted/30 dark:bg-muted/15" />
      </div>
       <div className="space-y-2 rounded-md p-3 bg-muted/20 dark:bg-muted/10 text-right">
        <Skeleton className="h-4 w-1/3 ml-auto rounded-sm bg-muted/30 dark:bg-muted/15" />
        <Skeleton className="h-4 w-full ml-auto rounded-sm bg-muted/30 dark:bg-muted/15" />
        <Skeleton className="h-4 w-4/5 ml-auto rounded-sm bg-muted/30 dark:bg-muted/15" />
      </div>
      <div className="space-y-1.5 rounded-md p-3 bg-muted/20 dark:bg-muted/10">
        <div className="flex items-center gap-2">
          <Skeleton className="h-4 w-1/4 rounded-sm bg-muted/30 dark:bg-muted/15" />
          <Skeleton className="h-4 w-full rounded-sm bg-muted/30 dark:bg-muted/15" />
        </div>
      </div>
      <div className="space-y-1.5 rounded-md p-3 bg-muted/20 dark:bg-muted/10 mt-2">
        <div className="flex items-center gap-2">
          <Skeleton className="h-4 w-1/5 rounded-sm bg-muted/30 dark:bg-muted/15" />
          <Skeleton className="h-4 w-3/4 rounded-sm bg-muted/30 dark:bg-muted/15" />
        </div>
      </div>
    </div>
  );
};


export function AppHeader() {
  const [mounted, setMounted] = useState(false);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  
  const [generalDua, setGeneralDua] = useState<DuaSuggestionOutput | null>(null);
  const [isLoadingGeneralDua, setIsLoadingGeneralDua] = useState(false);
  
  const [specificDuaQuery, setSpecificDuaQuery] = useState("");
  const [specificDuaResult, setSpecificDuaResult] = useState<DuaSuggestionOutput | null>(null);
  const [isSearchingSpecificDua, setIsSearchingSpecificDua] = useState(false);
  
  const [showDuaDialog, setShowDuaDialog] = useState(false);
  const [activeDuaView, setActiveDuaView] = useState<'suggestion' | 'search'>('suggestion');

  const [isDuaCopied, setIsDuaCopied] = useState(false);
  const [isDuaSpeaking, setIsDuaSpeaking] = useState(false);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);
  
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedMaleVoice, setSelectedMaleVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [speechSynthesisSupported, setSpeechSynthesisSupported] = useState(false);

  const { toast } = useToast();

  useEffect(() => {
    setMounted(true);
    const storedTheme = localStorage.getItem('hikmah-theme') as 'light' | 'dark' | null;
    const systemTheme = window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    const initialTheme = storedTheme || systemTheme;
    setTheme(initialTheme);
    if (initialTheme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    if (typeof window !== 'undefined' && window.speechSynthesis) {
      setSpeechSynthesisSupported(true);
      const loadVoices = () => {
        const availableVoices = window.speechSynthesis.getVoices();
        if (availableVoices.length > 0) {
          setVoices(availableVoices);
          let foundVoice = availableVoices.find(
            (voice) => voice.lang.startsWith('en-') && voice.name.toLowerCase().includes('male') && !voice.name.toLowerCase().includes('female')
          );
          if (!foundVoice) {
            foundVoice = availableVoices.find(
              (voice) => voice.lang.startsWith('en-') && (voice.name.toLowerCase().includes('david') || voice.name.toLowerCase().includes('mark') || voice.name.toLowerCase().includes('zira') === false)
            );
          }
          if (!foundVoice) {
            foundVoice = availableVoices.find(
              (voice) => voice.lang.startsWith('en-') && !voice.name.toLowerCase().includes('female')
            );
          }
           if (!foundVoice) {
            foundVoice = availableVoices.find(
              (voice) => voice.name.toLowerCase().includes('male')
            );
          }
          setSelectedMaleVoice(foundVoice || availableVoices.find(v => v.lang.startsWith('en-US')) || availableVoices[0] || null);
        }
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
      return () => {
        window.speechSynthesis.onvoiceschanged = null;
        if (window.speechSynthesis.speaking) {
          window.speechSynthesis.cancel();
        }
      };
    } else {
      setSpeechSynthesisSupported(false);
    }

  }, []);

  useEffect(() => {
    return () => {
      if (speechSynthesisSupported && window.speechSynthesis.speaking) {
        window.speechSynthesis.cancel();
      }
      setIsDuaSpeaking(false);
    };
  }, [showDuaDialog, speechSynthesisSupported]);


  const fetchAndSetGeneralDua = async () => {
    setIsLoadingGeneralDua(true);
    setGeneralDua(null); 
    try {
      const dua = await getGeneralDua();
      setGeneralDua(dua);
    } catch (error) {
      console.error("Failed to fetch general Dua:", error);
      setGeneralDua(null); 
      toast({
        title: "Error Fetching Dua",
        description: "Could not load a general Dua at this time. Please check your connection or API configuration.",
        variant: "destructive",
      });
    } finally {
      setIsLoadingGeneralDua(false);
    }
  };

  const handleSearchSpecificDua = async () => {
    if (!specificDuaQuery.trim()) {
      toast({ title: "Input Required", description: "Please enter what Dua you are looking for.", variant: "destructive" });
      return;
    }
    setIsSearchingSpecificDua(true);
    setSpecificDuaResult(null);
    try {
      const result = await duaSuggestion({ userInput: specificDuaQuery, history: [] });
      setSpecificDuaResult(result);
    } catch (error) {
      console.error("Failed to fetch specific Dua:", error);
      toast({
        title: "Search Error",
        description: "Could not find a Dua for your query or an error occurred.",
        variant: "destructive",
      });
    } finally {
      setIsSearchingSpecificDua(false);
    }
  };

  const toggleTheme = () => {
    const newTheme = theme === 'light' ? 'dark' : 'light';
    setTheme(newTheme);
    localStorage.setItem('hikmah-theme', newTheme);
    document.documentElement.classList.toggle('dark', newTheme === 'dark');
  };

  const headerClasses = `
    fixed top-0 left-0 right-0 z-50 py-3 px-6 shadow-lg 
    transition-colors duration-300 ease-in-out 
    border-b border-border/10 
    ${mounted ? 'bg-background/15 dark:bg-card/10 backdrop-blur-xl' : 'bg-card dark:bg-card'}
  `;

  const handleSparklesClick = () => {
    setShowDuaDialog(true);
    if (speechSynthesisSupported && window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setIsDuaSpeaking(false);
    }
    if (activeDuaView === 'suggestion' && !generalDua && !isLoadingGeneralDua) { 
        fetchAndSetGeneralDua();
    }           
  };
  
  const getDuaTextForActions = (dua: DuaSuggestionOutput | null): string => {
    if (!dua) return "";
    let text = `Dua:\n${dua.arabicText}\n\nTransliteration:\n${dua.transliteration}\n\nMeaning:\n${dua.englishMeaning}`;
    if (dua.urduKanzulImanTranslation) {
      text += `\n\nUrdu Translation (${dua.languageOfUrduTranslation || 'Urdu'}):\n${dua.urduKanzulImanTranslation}`;
    }
    if (dua.contextOrBenefit) {
      text += `\n\nContext/Benefit (${dua.languageOfExplanation || 'English'}):\n${dua.contextOrBenefit}`;
    }
    text += `\n\nSource: ${dua.source}`;
    return text;
  };

  const getDuaTextForSpeech = (dua: DuaSuggestionOutput | null): string => {
     if (!dua) return "";
    let textToSpeak = "";
    if (dua.englishMeaning) {
        textToSpeak += `Meaning: ${dua.englishMeaning}. `;
    }
    if (dua.urduKanzulImanTranslation) {
        textToSpeak += ` Urdu Translation: ${dua.urduKanzulImanTranslation}. `;
    }
     if (dua.contextOrBenefit) {
         textToSpeak += ` Context or Benefit: ${dua.contextOrBenefit}.`;
    }
    if (dua.source) {
        textToSpeak += ` Source: ${dua.source}. `;
    }
    return textToSpeak.trim();
  };

  const handleCopyDisplayedDua = () => {
    const duaToCopy = activeDuaView === 'search' ? specificDuaResult : generalDua;
    if (!duaToCopy) return;

    const textToCopy = getDuaTextForActions(duaToCopy);
    navigator.clipboard.writeText(textToCopy).then(() => {
      setIsDuaCopied(true);
      toast({ title: "Dua details copied!", duration: 2000 });
      setTimeout(() => setIsDuaCopied(false), 2000);
    }).catch(err => {
      console.error("Failed to copy Dua: ", err);
      toast({ title: "Failed to copy", variant: "destructive", duration: 2000 });
    });
  };

  const handleReadAloudDisplayedDua = async () => {
    if (!speechSynthesisSupported) {
      toast({ title: "Speech Synthesis Not Supported", description: "Your browser does not support text-to-speech.", variant: "destructive" });
      return;
    }

    const duaToRead = activeDuaView === 'search' ? specificDuaResult : generalDua;
    if (!duaToRead) return;

    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setIsDuaSpeaking(false);
      return;
    }

    const textToSpeak = getDuaTextForSpeech(duaToRead);
    if (!textToSpeak) {
       toast({ title: "Nothing to read", description: "No content available to read aloud for this Dua.", duration: 2000 });
       return;
    }
    
    setIsDuaSpeaking(true);

    const utterance = new SpeechSynthesisUtterance(textToSpeak);
    if (selectedMaleVoice) {
      utterance.voice = selectedMaleVoice;
    }
    utterance.rate = 0.9;
    utterance.pitch = 1.0;
    
    currentUtteranceRef.current = utterance;

    utterance.onend = () => {
      setIsDuaSpeaking(false);
      currentUtteranceRef.current = null;
    };
    utterance.onerror = (event) => {
      if (event.error === 'interrupted') {
        console.log('Dua modal speech synthesis interrupted:', event.error);
      } else {
        console.error('Speech synthesis error (Dua Modal):', event.error);
        toast({ title: "Speech Error", description: `Could not play audio: ${event.error}`, variant: "destructive" });
      }
      setIsDuaSpeaking(false);
      currentUtteranceRef.current = null;
    };

    window.speechSynthesis.speak(utterance);
  };

  const renderDuaContent = (dua: DuaSuggestionOutput | null) => {
    if (!dua) return <p className="text-muted-foreground text-center py-4">No Dua to display.</p>;
    return (
      <div className="py-2 space-y-3">
          {dua.arabicText && (
            <div className="dua-arabic-text-container text-right font-arabic text-2xl md:text-3xl whitespace-pre-wrap break-words leading-loose">
              {dua.arabicText}
            </div>
          )}
          {dua.transliteration && (
            <div className="dua-translation-section">
              <p className="mb-1">Transliteration:</p>
              <p className="italic">{dua.transliteration}</p>
            </div>
          )}
          {dua.englishMeaning && (
            <div className="dua-translation-section">
              <p className="mb-1">Meaning:</p>
              <p>{dua.englishMeaning}</p>
            </div>
          )}
          {dua.urduKanzulImanTranslation && (
            <div className="dua-translation-section">
              <p className="mb-1 text-right font-arabic">({dua.languageOfUrduTranslation || 'Urdu'}) ترجمہ:</p>
              <p className="font-arabic text-right text-lg">{dua.urduKanzulImanTranslation}</p>
            </div>
          )}
          
          {(dua.contextOrBenefit || dua.source) && (
            <div className="dua-translation-section source-context space-y-2.5">
              {dua.contextOrBenefit && (
                <div>
                  <strong className="block mb-0.5">Context/Benefit ({dua.languageOfExplanation || 'English'}):</strong>
                  <p>{dua.contextOrBenefit}</p>
                </div>
              )}
              {dua.source && (
                <div>
                  <strong className="block mb-0.5">Source:</strong>
                  <code>{dua.source}</code>
                </div>
              )}
            </div>
          )}
        
        {(dua.arabicText || dua.englishMeaning) && ( 
            <div className="action-button-group mt-4">
                <Button variant="ghost" size="icon" onClick={handleCopyDisplayedDua} className="action-button dark:neon-glow-accent" aria-label="Copy Dua">
                    {isDuaCopied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                </Button>
                <Button variant="ghost" size="icon" onClick={handleReadAloudDisplayedDua} disabled={!speechSynthesisSupported} className={cn("action-button dark:neon-glow-accent", isDuaSpeaking ? "text-accent animate-pulse" : "", !speechSynthesisSupported ? "opacity-50 cursor-not-allowed" : "")} aria-label={isDuaSpeaking ? "Stop reading" : "Read Dua aloud"}>
                    <Volume2 size={18} />
                </Button>
            </div>
        )}
      </div>
    );
  };

  const handleTabChange = (view: 'suggestion' | 'search') => {
    if (speechSynthesisSupported && window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setIsDuaSpeaking(false);
    }
    setActiveDuaView(view);
    if (view === 'suggestion') {
      setSpecificDuaResult(null);
      setSpecificDuaQuery("");
      if (!generalDua && !isLoadingGeneralDua) {
        fetchAndSetGeneralDua();
      }
    }
  };

  return (
    <>
      <header className={headerClasses}>
        <div className="container mx-auto flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-headline text-primary dark:text-primary">Hikmah AI</h1>
              <p className="text-xs text-muted-foreground font-body dark:text-muted-foreground">Your Guide to Islamic Knowledge</p>
            </div>
          <div className="flex items-center gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={handleSparklesClick}
              aria-label="View a Dua Suggestion"
              className="text-foreground hover:bg-muted/80 dark:text-foreground dark:hover:bg-muted/60 dark:neon-glow-accent transition-all duration-150 ease-in-out"
            >
              <Sparkles className="h-5 w-5" />
            </Button>
            {mounted && (
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                aria-label={theme === 'light' ? 'Switch to dark mode' : 'Switch to light mode'}
                className="text-foreground hover:bg-muted/80 dark:text-foreground dark:hover:bg-muted/60 dark:neon-glow-accent transition-all duration-150 ease-in-out"
              >
                {theme === 'light' ? <Moon className="h-5 w-5" /> : <Sun className="h-5 w-5" />}
              </Button>
            )}
          </div>
        </div>
      </header>

      {showDuaDialog && (
          <AlertDialog open={showDuaDialog} onOpenChange={(open) => {
              if (!open && speechSynthesisSupported && window.speechSynthesis.speaking) {
                window.speechSynthesis.cancel();
                setIsDuaSpeaking(false);
              }
              setShowDuaDialog(open);
              if (!open) { 
                setSpecificDuaResult(null);
                setSpecificDuaQuery("");
              }
          }}>
              <AlertDialogContent className="max-w-lg">
                <AlertDialogHeader className="pb-2">
                  <AlertDialogTitle className="font-headline text-2xl text-center text-accent dark:neon-glow-accent mb-3">
                    Dua Corner
                  </AlertDialogTitle>
                  <div className="flex border-b">
                    <Button
                      variant={'ghost'}
                      onClick={() => handleTabChange('suggestion')}
                      className={cn(
                        "flex-1 justify-center rounded-none rounded-tl-md hover:bg-muted/70 dark:hover:bg-muted/40 py-3 focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none transition-all duration-150 ease-in-out",
                        activeDuaView === 'suggestion' ? 'border-b-2 border-primary text-primary dark:text-primary font-semibold shadow-sm bg-muted/20 dark:bg-muted/10' : 'text-muted-foreground'
                      )}
                    >
                      <Sparkles size={18} className="mr-2" />
                      Suggested Dua
                    </Button>
                    <Button
                      variant={'ghost'}
                      onClick={() => handleTabChange('search')}
                      className={cn(
                        "flex-1 justify-center rounded-none rounded-tr-md hover:bg-muted/70 dark:hover:bg-muted/40 py-3 focus-visible:ring-1 focus-visible:ring-ring focus-visible:outline-none transition-all duration-150 ease-in-out",
                        activeDuaView === 'search' ? 'border-b-2 border-primary text-primary dark:text-primary font-semibold shadow-sm bg-muted/20 dark:bg-muted/10' : 'text-muted-foreground'
                      )}
                    >
                      <Search size={18} className="mr-2" />
                      Search for Dua
                    </Button>
                  </div>
                </AlertDialogHeader>
                
                <ScrollArea className="max-h-[60vh] -mx-6 px-6 pt-1 pb-2"> 
                  {activeDuaView === 'suggestion' && (
                    <>
                      {isLoadingGeneralDua ? <DuaContentSkeleton /> : renderDuaContent(generalDua)}
                    </>
                  )}

                  {activeDuaView === 'search' && (
                    <div className="space-y-4 pt-2">
                      <Textarea
                        placeholder="E.g., 'Dua for anxiety', 'Dua before eating'..."
                        value={specificDuaQuery}
                        onChange={(e) => setSpecificDuaQuery(e.target.value)}
                        rows={2}
                        className="text-base"
                      />
                      <Button 
                        onClick={handleSearchSpecificDua} 
                        disabled={isSearchingSpecificDua || !specificDuaQuery.trim()}
                        className="w-full bg-primary hover:bg-primary/90 text-primary-foreground dark:neon-glow-primary"
                      >
                        {isSearchingSpecificDua ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Search className="mr-2 h-4 w-4" />}
                        Search Dua
                      </Button>
                      {isSearchingSpecificDua && <div className="py-4"><DuaContentSkeleton /></div>}
                      {specificDuaResult && !isSearchingSpecificDua && (
                        <div className="mt-2"> 
                          {renderDuaContent(specificDuaResult)}
                        </div>
                      )}
                    </div>
                  )}
                </ScrollArea>
                
                <AlertDialogFooter className="mt-2 pt-4 border-t">
                  <AlertDialogAction
                    onClick={() => setShowDuaDialog(false)}
                    className="w-full sm:w-auto bg-primary hover:bg-primary/90 text-primary-foreground dark:neon-glow-primary"
                  >
                    Close
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
        )}
    </>
  );
}
