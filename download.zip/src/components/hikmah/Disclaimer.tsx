
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle } from "lucide-react";

interface DisclaimerProps {
  isPopupVersion?: boolean;
}

export function Disclaimer({ isPopupVersion = false }: DisclaimerProps) {
  const content = (
    <>
      <p>
        Hikmah AI is an artificial intelligence tool designed for informational purposes and general guidance on Islamic topics based on its learned data. It is <strong>not</strong> a qualified Islamic scholar and is <strong>not authorized</strong> to issue religious rulings (fatwas).
      </p>
      <p>
        For specific religious questions, interpretations, or fatwas, it is essential to consult with a qualified and trusted Islamic scholar in your community.
      </p>
      <p className="mt-1">
        While Hikmah AI strives to provide responses that align with mainstream Islamic teachings and scholarly consensus, and to avoid sectarianism, extremism, or content inciting violence, the information should always be verified with authentic sources and scholars.
      </p>
    </>
  );

  if (isPopupVersion) {
    // Return the fragment of <p> tags directly.
    // The parent div in ChatPageClient will handle styling and spacing.
    return <>{content}</>;
  }

  return (
    <Card className="my-4 border-2 border-accent shadow-xl bg-accent/10 dark:bg-accent/20 dark:border-accent rounded-lg">
      <CardHeader className="flex flex-row items-center gap-3 pb-3">
        <AlertTriangle className="h-7 w-7 text-accent dark:neon-glow-accent" />
        <CardTitle className="font-headline text-accent dark:neon-glow-accent text-2xl">Important Disclaimer</CardTitle>
      </CardHeader>
      <CardContent className="text-sm text-foreground/90 dark:text-foreground/80 space-y-2 pl-12">
        {content}
      </CardContent>
    </Card>
  );
}
