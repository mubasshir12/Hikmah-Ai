
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";

export function ChatMessageSkeleton() {
  return (
    <div className={cn("w-full animate-pulse py-2")}>
      <div className="space-y-2.5">
        <Skeleton className="h-4 w-11/12 bg-muted/50 dark:bg-muted/25 rounded-md" />
        <Skeleton className="h-4 w-5/6 bg-muted/50 dark:bg-muted/25 rounded-md" />
        <Skeleton className="h-4 w-3/4 bg-muted/50 dark:bg-muted/25 rounded-md" />
        
        {/* Dua Skeleton Part - Always rendered for consistent height */}
        <div className="mt-4 pt-3 border-t border-border/30 space-y-3 bg-transparent p-0"> 
            <Skeleton className="h-5 w-1/3 bg-muted/40 dark:bg-muted/20 rounded-md" /> 
            <Skeleton className="h-10 w-full bg-muted/30 dark:bg-muted/15 rounded-md" /> 
            <div className="space-y-2 pt-1">
                <Skeleton className="h-3 w-1/4 bg-muted/40 dark:bg-muted/20 rounded-md" />
                <Skeleton className="h-3 w-full bg-muted/30 dark:bg-muted/15 rounded-md" />
            </div>
             <div className="space-y-2 pt-1">
                <Skeleton className="h-3 w-1/4 bg-muted/40 dark:bg-muted/20 rounded-md" />
                <Skeleton className="h-3 w-full bg-muted/30 dark:bg-muted/15 rounded-md" />
            </div>
             <div className="space-y-2 pt-1">
                <Skeleton className="h-3 w-1/5 bg-muted/40 dark:bg-muted/20 rounded-md" />
                <Skeleton className="h-3 w-3/4 bg-muted/30 dark:bg-muted/15 rounded-md" />
            </div>
        </div>
        
        <Skeleton className="h-3 w-1/5 mt-2 bg-muted/40 dark:bg-muted/20 rounded-md" /> 
      </div>
    </div>
  );
}
