
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { BookOpenText, Copy, Volume2, Check, Edit2 } from "lucide-react";
import { formatDistanceToNow } from 'date-fns';
import { ReactNode, useState, useEffect, useRef } from "react"; 
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { useToast } from "@/hooks/use-toast";
import { ChatMessageSkeleton } from "./ChatMessageSkeleton";


export type Message = {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string | ReactNode;
  duaDetails?: {
    arabicText: string;
    transliteration: string;
    englishMeaning: string;
    urduKanzulImanTranslation?: string;
    languageOfUrduTranslation?: string;
    source: string;
    contextOrBenefit?: string;
    languageOfExplanation?: string; // For contextOrBenefit
  };
  timestamp: Date;
  isLoading?: boolean;
};

interface ChatMessageProps {
  message: Message;
  onEditMessage?: (content: string) => void;
}

const LONG_PRESS_DURATION = 500; 

export function ChatMessage({ message, onEditMessage }: ChatMessageProps) {
  const isUser = message.role === 'user';
  const isAssistant = message.role === 'assistant';
  const { toast } = useToast();
  const [isAssistantContentCopied, setIsAssistantContentCopied] = useState(false);
  const [isUserContentCopied, setIsUserContentCopied] = useState(false);
  
  const [isSpeaking, setIsSpeaking] = useState(false);
  const currentUtteranceRef = useRef<SpeechSynthesisUtterance | null>(null);

  const [isEditControlsVisible, setIsEditControlsVisible] = useState(false);
  const longPressTimerRef = useRef<NodeJS.Timeout | null>(null);
  const editControlsRef = useRef<HTMLDivElement>(null);

  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedMaleVoice, setSelectedMaleVoice] = useState<SpeechSynthesisVoice | null>(null);
  const [speechSynthesisSupported, setSpeechSynthesisSupported] = useState(false);


  useEffect(() => {
    setIsEditControlsVisible(false);
    setIsUserContentCopied(false); 

    if (typeof window !== 'undefined' && window.speechSynthesis) {
      setSpeechSynthesisSupported(true);
      const loadVoices = () => {
        const availableVoices = window.speechSynthesis.getVoices();
        if (availableVoices.length > 0) {
          setVoices(availableVoices);
           let foundVoice = availableVoices.find(
            (voice) => voice.lang.startsWith('en-') && voice.name.toLowerCase().includes('male') && !voice.name.toLowerCase().includes('female')
          );
          if (!foundVoice) {
            foundVoice = availableVoices.find(
              (voice) => voice.lang.startsWith('en-') && (voice.name.toLowerCase().includes('david') || voice.name.toLowerCase().includes('mark') || voice.name.toLowerCase().includes('zira') === false)
            );
          }
          if (!foundVoice) {
            foundVoice = availableVoices.find(
              (voice) => voice.lang.startsWith('en-') && !voice.name.toLowerCase().includes('female')
            );
          }
          if (!foundVoice) { 
            foundVoice = availableVoices.find(
              (voice) => voice.name.toLowerCase().includes('male')
            );
          }
          setSelectedMaleVoice(foundVoice || availableVoices.find(v => v.lang.startsWith('en-US')) || availableVoices[0] || null);
        }
      };
      loadVoices();
      window.speechSynthesis.onvoiceschanged = loadVoices;
      
      return () => {
        window.speechSynthesis.onvoiceschanged = null;
        if (window.speechSynthesis.speaking && currentUtteranceRef.current) {
           window.speechSynthesis.cancel(); 
        }
        setIsSpeaking(false);
        currentUtteranceRef.current = null;
        clearLongPressTimer(); 
      };
    } else {
      setSpeechSynthesisSupported(false);
    }
  }, [message.id]);


  useEffect(() => {
    if (!isEditControlsVisible) return;

    const handleClickOutside = (event: MouseEvent) => {
      if (editControlsRef.current && !editControlsRef.current.contains(event.target as Node)) {
        setIsEditControlsVisible(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [isEditControlsVisible]);


  const clearLongPressTimer = () => {
    if (longPressTimerRef.current) {
      clearTimeout(longPressTimerRef.current);
      longPressTimerRef.current = null;
    }
  };

  const handlePressStart = (event: React.MouseEvent | React.TouchEvent) => {
    if (!isUser || typeof message.content !== 'string') return;
    clearLongPressTimer();
    longPressTimerRef.current = setTimeout(() => {
      setIsEditControlsVisible(true);
    }, LONG_PRESS_DURATION);
  };

  const handlePressEnd = () => {
    clearLongPressTimer();
  };

  const handleEditButtonClick = () => {
    if (isUser && onEditMessage && typeof message.content === 'string') {
      onEditMessage(message.content);
      setIsEditControlsVisible(false); 
    }
  };

  const handleCopyAssistantContent = () => {
    let textToCopy = "";
    if (typeof message.content === 'string') {
      textToCopy = message.content;
    }
    if (message.duaDetails) {
      textToCopy += `\n\n--- Dua Details ---\n`;
      textToCopy += `Arabic: ${message.duaDetails.arabicText}\n`;
      textToCopy += `Transliteration: ${message.duaDetails.transliteration}\n`;
      textToCopy += `Meaning: ${message.duaDetails.englishMeaning}\n`;
      if (message.duaDetails.urduKanzulImanTranslation) {
        textToCopy += `Urdu Translation (${message.duaDetails.languageOfUrduTranslation || 'Urdu'}): ${message.duaDetails.urduKanzulImanTranslation}\n`;
      }
      textToCopy += `Source: ${message.duaDetails.source}\n`;
      if (message.duaDetails.contextOrBenefit) {
        textToCopy += `Context/Benefit (${message.duaDetails.languageOfExplanation || 'English'}): ${message.duaDetails.contextOrBenefit}\n`;
      }
    }

    navigator.clipboard.writeText(textToCopy.trim()).then(() => {
      setIsAssistantContentCopied(true);
      toast({ title: "Copied to clipboard!", duration: 2000 });
      setTimeout(() => setIsAssistantContentCopied(false), 2000);
    }).catch(err => {
      console.error("Failed to copy: ", err);
      toast({ title: "Failed to copy", variant: "destructive", duration: 2000 });
    });
  };

  const handleCopyUserMessage = () => {
    if (isUser && typeof message.content === 'string') {
      navigator.clipboard.writeText(message.content).then(() => {
        setIsUserContentCopied(true);
        toast({ title: "Message copied!", duration: 2000 });
        setTimeout(() => setIsUserContentCopied(false), 2000);
      }).catch(err => {
        console.error("Failed to copy user message: ", err);
        toast({ title: "Failed to copy", variant: "destructive", duration: 2000 });
      });
    }
    setIsEditControlsVisible(false); 
  };


  const handleReadAloud = async () => {
    if (!speechSynthesisSupported) {
      toast({ title: "Speech Synthesis Not Supported", description: "Your browser does not support text-to-speech.", variant: "destructive" });
      return;
    }

    if (window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
      setIsSpeaking(false);
      return;
    }

    let textToSpeak = "";
    if (typeof message.content === 'string') {
      textToSpeak = message.content
        .replace(/#+\s*/g, '') 
        .replace(/[*_~`]/g, '')    
        .replace(/\[(.*?)\]\(.*?\)/g, '$1'); 
    }
    if (message.duaDetails) {
      textToSpeak += ` Suggested Dua. ${message.duaDetails.englishMeaning}.`;
      if (message.duaDetails.urduKanzulImanTranslation) {
        textToSpeak += ` Urdu Translation: ${message.duaDetails.urduKanzulImanTranslation}.`;
      }
      textToSpeak += ` Source: ${message.duaDetails.source}.`;
      if (message.duaDetails.contextOrBenefit) {
         textToSpeak += ` Context or Benefit (${message.duaDetails.languageOfExplanation || 'English'}): ${message.duaDetails.contextOrBenefit}.`;
      }
    }
    
    const finalTextToSpeak = textToSpeak.trim();
    if (!finalTextToSpeak) {
       toast({
        title: "Nothing to read",
        description: "There is no text content to read aloud for this message.",
        duration: 2000
      });
      setIsSpeaking(false);
      return;
    }

    setIsSpeaking(true);

    const utterance = new SpeechSynthesisUtterance(finalTextToSpeak);
    if (selectedMaleVoice) {
      utterance.voice = selectedMaleVoice;
    }
    utterance.rate = 0.9; 
    utterance.pitch = 1.0; 
    
    currentUtteranceRef.current = utterance;

    utterance.onend = () => {
      setIsSpeaking(false);
      currentUtteranceRef.current = null;
    };
    utterance.onerror = (event) => {
      if (event.error === 'interrupted') {
        console.info('Chat message speech synthesis interrupted (likely intentional):', event.error);
      } else {
        console.error("Speech synthesis error for chat message:", event.error);
        toast({ title: "Speech Error", description: `Could not play audio: ${event.error}`, variant: "destructive" });
      }
      setIsSpeaking(false);
      currentUtteranceRef.current = null;
    };

    window.speechSynthesis.speak(utterance);
  };
  
  const assistantMessageContent = (
    <div className="w-full">
      {typeof message.content === 'string' ? (
        <div className="markdown-content break-words leading-relaxed text-base">
          <ReactMarkdown remarkPlugins={[remarkGfm]}>
            {message.content}
          </ReactMarkdown>
        </div>
      ) : (
        message.content
      )}

      {message.duaDetails && (
        <div className="dua-block-container">
          <div className="flex items-center gap-2 mb-3">
            <BookOpenText size={20} className="text-accent dark:neon-glow-accent" />
            <h4 className="font-semibold text-lg text-accent dark:neon-glow-accent font-headline">Suggested Dua:</h4>
          </div>
          
          {message.duaDetails.arabicText && (
            <div className="dua-arabic-text-container font-arabic text-2xl md:text-3xl text-right whitespace-pre-wrap break-words leading-loose">
              {message.duaDetails.arabicText}
            </div>
          )}

          {message.duaDetails.transliteration && (
            <div className="dua-translation-section">
              <p>Transliteration:</p>
              <p className="italic">{message.duaDetails.transliteration}</p>
            </div>
          )}

          {message.duaDetails.englishMeaning && (
            <div className="dua-translation-section">
              <p>Meaning:</p>
              <p>{message.duaDetails.englishMeaning}</p>
            </div>
          )}

          {message.duaDetails.urduKanzulImanTranslation && (
             <div className="dua-translation-section">
              <p>Urdu Translation ({message.duaDetails.languageOfUrduTranslation || 'Urdu'}):</p>
              <p className="font-arabic text-right text-lg">{message.duaDetails.urduKanzulImanTranslation}</p>
            </div>
          )}
          
          <div className="dua-translation-section source-context">
            <p>
              <strong>Source:</strong> <code>{message.duaDetails.source}</code>
            </p>
            {message.duaDetails.contextOrBenefit && (
               <p>
                 <strong>Context/Benefit ({message.duaDetails.languageOfExplanation || 'English'}):</strong> {message.duaDetails.contextOrBenefit}
               </p>
            )}
          </div>
        </div>
      )}
      
      <div className="action-button-group">
          {isAssistant && (typeof message.content === 'string' && message.content.length > 0 || message.duaDetails) && (
            <>
              <Button variant="ghost" size="icon" onClick={handleCopyAssistantContent} className="action-button dark:neon-glow-accent" aria-label="Copy message">
                {isAssistantContentCopied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
              </Button>
              <Button variant="ghost" size="icon" onClick={handleReadAloud} disabled={!speechSynthesisSupported} className={cn("action-button dark:neon-glow-accent", isSpeaking ? "text-accent animate-pulse" : "", !speechSynthesisSupported ? "opacity-50 cursor-not-allowed" : "")} aria-label={isSpeaking ? "Stop reading" : "Read message aloud"}>
                <Volume2 size={18} />
              </Button>
            </>
          )}
        </div>
    </div>
  );

  if (isAssistant && message.isLoading) {
    return (
      <div className="flex w-full mb-6 justify-start">
        <div className="flex flex-col gap-1 items-start max-w-[95%] w-full">
          <ChatMessageSkeleton />
          <p className="text-xs opacity-70 pl-1 text-left">
            <span className="inline-block h-3 w-16 bg-muted/40 dark:bg-muted/25 rounded-md animate-pulse"></span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("flex w-full mb-6", isUser ? "justify-end" : "justify-start")}>
      <div className={cn(
          "flex flex-col gap-1", 
          isUser ? "items-end" : "items-start",
          isUser ? "max-w-[85%]" : "w-full max-w-[95%]" 
        )}
      >
        {isUser ? (
          <>
            <div 
              onMouseDown={handlePressStart}
              onTouchStart={handlePressStart}
              onMouseUp={handlePressEnd}
              onTouchEnd={handlePressEnd}
              onMouseLeave={handlePressEnd} 
              className="cursor-default select-none relative" 
            >
              <Card className="bg-primary text-primary-foreground rounded-2xl rounded-tr-sm shadow-xl">
                <CardContent className="px-3.5 py-2.5">
                  {typeof message.content === 'string' ? (
                    <div className="markdown-content break-words leading-relaxed text-base text-primary-foreground">
                      <ReactMarkdown remarkPlugins={[remarkGfm]} components={{ p: ({node, ...props}) => <p className="text-primary-foreground" {...props} /> }}>{message.content}</ReactMarkdown>
                    </div>
                  ) : ( message.content )}
                </CardContent>
              </Card>
               {/* Tail element */}
              <div className="absolute top-1 -right-[7px] w-0 h-0 
                              border-t-[8px] border-t-transparent
                              border-l-[10px] border-l-primary 
                              border-b-[8px] border-b-transparent
                              dark:border-l-primary">
              </div>
            </div>
            {isEditControlsVisible && (
              <div 
                ref={editControlsRef}
                className={cn(
                  "flex items-center gap-2 mt-1.5 mb-0.5",
                  "transition-all duration-300 ease-in-out", 
                  isEditControlsVisible ? "opacity-100 scale-100" : "opacity-0 scale-95" 
                )}
              >
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleEditButtonClick}
                  className="action-button dark:neon-glow-primary"
                  aria-label="Edit message"
                >
                  <Edit2 size={18} />
                </Button>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={handleCopyUserMessage}
                  className="action-button dark:neon-glow-primary"
                  aria-label="Copy user message"
                >
                  {isUserContentCopied ? <Check size={18} className="text-green-500" /> : <Copy size={18} />}
                </Button>
              </div>
            )}
          </>
        ) : (
          assistantMessageContent 
        )}

        <p className={cn("text-xs opacity-70", isUser ? "pr-1 text-right" : "pl-1 text-left")}>
          {formatDistanceToNow(new Date(message.timestamp), { addSuffix: true })}
        </p>

      </div>
    </div>
  );
}
