
"use client";

import { Skeleton } from "@/components/ui/skeleton";
import { ChatMessageSkeleton } from "./ChatMessageSkeleton";
import { cn } from "@/lib/utils";

export function FullPageChatSkeleton() {
  return (
    <div className="flex flex-col h-screen bg-background animate-pulse calligraphy-watermark-bg overflow-hidden">
      {/* AppHeader Skeleton - Mimicking actual structure and padding */}
      <div className="py-3 px-6 shadow-lg border-b border-border/10 bg-card dark:bg-card">
        <div className="container mx-auto flex items-center justify-between h-[calc(70px-1.5rem)]"> {/* Approx AppHeader height minus py-3 */}
          <div>
            <Skeleton className="h-8 w-32 mb-1.5 rounded-md bg-muted" /> {/* Hikmah AI Title */}
            <Skeleton className="h-3 w-48 rounded-md bg-muted" />     {/* Subtitle */}
          </div>
          <div className="flex items-center gap-2">
            <Skeleton className="h-9 w-9 rounded-md bg-muted" /> {/* Sparkles button */}
            <Skeleton className="h-9 w-9 rounded-md bg-muted" /> {/* Theme button */}
          </div>
        </div>
      </div>

      {/* ScrollArea Content Skeleton - Flex-grow to take available space, overflow-hidden to prevent its own scroll */}
      <div className="flex-grow overflow-hidden">
        <div className="container mx-auto max-w-3xl px-4 pt-4 pb-4 h-full"> {/* h-full might be tricky with flex-grow, let's see */}
          {/* DailyWisdom Skeleton */}
          <div className="mb-4 p-4 rounded-lg shadow-lg border border-accent/30 bg-card">
            <div className="flex items-center gap-2 mb-3">
                <Skeleton className="h-5 w-5 rounded-full bg-muted" />
                <Skeleton className="h-5 w-2/5 rounded-md bg-muted" />
            </div>
            <Skeleton className="h-5 w-full mb-2 rounded-md bg-muted" />
            <Skeleton className="h-4 w-4/5 mb-2 rounded-md bg-muted" />
            <Skeleton className="h-4 w-1/3 ml-auto rounded-md bg-muted" />
          </div>

          {/* ChatMessages Skeleton - Limited to what's visible */}
          <div className="space-y-4"> {/* Reduced spacing from space-y-6 */}
            {/* Assistant Message Skeleton */}
            <div className="flex w-full justify-start">
              <div className="flex flex-col gap-1 items-start w-4/5">
                {/* Using a simplified version for the main page skeleton to avoid excessive height */}
                <div className={cn("w-full animate-pulse py-1")}>
                    <div className="space-y-2">
                        <Skeleton className="h-4 w-11/12 bg-muted/60 dark:bg-muted/30 rounded-md" />
                        <Skeleton className="h-4 w-5/6 bg-muted/60 dark:bg-muted/30 rounded-md" />
                        {/* No Dua block skeleton here to keep it shorter for the initial page view */}
                    </div>
                </div>
                <Skeleton className="h-3 w-20 ml-1 rounded-md bg-muted" /> {/* Timestamp */}
              </div>
            </div>

             {/* User Message Skeleton - Optional, if space allows visually */}
            <div className="flex w-full justify-end">
              <div className="flex flex-col items-end gap-1 w-3/5">
                  <Skeleton className="h-10 w-full rounded-2xl rounded-tr-sm bg-primary/30 dark:bg-primary/20" />
                  <Skeleton className="h-3 w-16 mr-1 rounded-md bg-muted" /> {/* Timestamp */}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Chat Input Area Skeleton */}
      <div className="border-t border-border/50 bg-card dark:bg-background/80 p-3 shadow-top-lg rounded-tl-[32px] rounded-tr-[32px]">
        <div className="container mx-auto max-w-3xl flex items-end gap-2">
          <Skeleton className="flex-grow h-[52px] rounded-2xl bg-muted" />
          <Skeleton className="h-[52px] w-[52px] rounded-full bg-primary/40 dark:bg-primary/30" />
        </div>
      </div>
    </div>
  );
}
