
"use client";

import { useState, useRef, useEffect, FormEvent, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Send, Quote, ChevronLeft, ChevronRight } from "lucide-react"; 
import { AppHeader } from "./AppHeader";
import { Disclaimer } from "./Disclaimer";
import { ChatMessage, type Message } from "./ChatMessage";
import { islamicScholarQuery } from "@/ai/flows/islamic-scholar-query";
import { getDailyWisdom } from "@/ai/flows/daily-wisdom-flow";
import type { DailyWisdomOutput } from "@/ai/schemas/daily-wisdom-schemas";
import { useToast } from "@/hooks/use-toast";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogContent,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { AlertTriangle } from "lucide-react";
import type { MessageData } from 'genkit';
import { Skeleton } from "@/components/ui/skeleton";
import { cn } from "@/lib/utils";
import { FullPageChatSkeleton } from "./FullPageChatSkeleton";
import { DailyDuaCard } from "./DailyDuaCard";
import { useIsMobile } from "@/hooks/use-mobile";


const DailyWisdom = () => {
  const [wisdom, setWisdom] = useState<DailyWisdomOutput | null>(null);
  const [isLoadingWisdom, setIsLoadingWisdom] = useState(true);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    const fetchWisdom = async () => {
      setIsLoadingWisdom(true);
      try {
        const result = await getDailyWisdom();
        setWisdom(result);
      } catch (error) {
        console.error("Failed to fetch daily wisdom:", error);
        setWisdom({
          wisdomText: "The best of people are those who are most beneficial to people.",
          wisdomSource: "Hadith (Sahih al-Jami)",
        });
      } finally {
        setIsLoadingWisdom(false);
      }
    };
    fetchWisdom();
  }, []);


  if (!mounted || isLoadingWisdom) {
    return (
        <Card className="w-full h-full shadow-lg border-accent/50 bg-gradient-to-br from-background to-muted/30 dark:from-background dark:to-muted/20 flex flex-col">
            <CardHeader className="pb-2 pt-4">
                 <div className="flex items-center gap-2 text-accent dark:text-accent dark:neon-glow-accent">
                    <Quote size={20} />
                    <CardTitle className="font-headline text-xl">Daily Hikmah (Wisdom)</CardTitle>
                </div>
            </CardHeader>
            <CardContent className="pb-4 flex-grow flex flex-col justify-center">
                <Skeleton className="h-6 w-full mb-1 rounded-md" /> 
                <Skeleton className="h-4 w-3/4 mb-2 rounded-md" />
                <Skeleton className="h-4 w-1/3 ml-auto mt-1 rounded-md" />
            </CardContent>
        </Card>
    );
  }

  if (!wisdom) return null;

  return (
    <Card className="w-full h-full shadow-lg border-accent/50 bg-gradient-to-br from-background to-muted/30 dark:from-background dark:to-muted/20 flex flex-col">
      <CardHeader className="pb-2 pt-4">
        <div className="flex items-center gap-2 text-accent dark:text-accent dark:neon-glow-accent">
          <Quote size={20} />
          <CardTitle className="font-headline text-xl">Daily Hikmah (Wisdom)</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pb-4 flex-grow flex flex-col justify-center">
        <blockquote className="italic text-foreground/90 dark:text-foreground/80 text-center text-lg py-2">
          "{wisdom.wisdomText}"
        </blockquote>
        <p className="text-right text-sm text-muted-foreground dark:text-muted-foreground/70 mt-1">- {wisdom.wisdomSource}</p>
      </CardContent>
    </Card>
  );
};


export default function ChatPageClient() {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showDisclaimerDialog, setShowDisclaimerDialog] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement | null>(null);
  const { toast } = useToast();
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const [headerHeight, setHeaderHeight] = useState(80); 
  const [mounted, setMounted] = useState(false);
  const [isInitialPageLoading, setIsInitialPageLoading] = useState(true);

  const placeholderTexts = useMemo(() => [
    "Ask about Salah timings...",
    "What is Zakat?",
    "Tell me about Prophet Muhammad (PBUH)...",
    "Explain the pillars of Iman...",
    "Dua for guidance...",
    "Stories of the Prophets...",
    "What are the Hadith?",
    "Meaning of Alhamdulillah...",
  ], []);
  const [currentPlaceholderIndex, setCurrentPlaceholderIndex] = useState(0);
  const [displayedPlaceholder, setDisplayedPlaceholder] = useState("");
  const [placeholderPhase, setPlaceholderPhase] = useState<'typing-in' | 'holding' | 'typing-out'>('typing-in');

  const typingSpeed = 70; 
  const deletingSpeed = 40; 
  const holdDuration = 4000; 

  const isMobile = useIsMobile();
  const [activeCardIndex, setActiveCardIndex] = useState(0);
  const cardsContainerRef = useRef<HTMLDivElement>(null);
  const cardElementsRef = useRef<(HTMLDivElement | null)[]>([]);
  const cardItems = useMemo(() => ['wisdom', 'dua'], []); 
  
  const isProgrammaticScroll = useRef(false);


 useEffect(() => {
    const timer = setTimeout(() => {
      setIsInitialPageLoading(false);
    }, 1500); 
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    setMounted(true);
    const headerElement = document.querySelector('header');
    if (headerElement) {
      const currentHeaderHeight = headerElement.offsetHeight;
      if (currentHeaderHeight > 0) { 
        setHeaderHeight(currentHeaderHeight);
      }
    }

    setMessages([
      {
        id: Date.now().toString(),
        role: 'assistant',
        content: "As-salamu alaykum! I am Hikmah AI. I am here to assist you with your questions on Islamic topics, all in accordance with established Islamic teachings. You can also find a Dua suggestion in the header. How may I help you today?",
        timestamp: new Date(),
        isLoading: false,
      }
    ]);
    if (typeof window !== 'undefined') {
        if (window.speechSynthesis) {
            window.speechSynthesis.getVoices(); 
        }
        const disclaimerDismissed = localStorage.getItem('hikmah-disclaimer-dismissed');
        if (!disclaimerDismissed) {
            setShowDisclaimerDialog(true);
        }
    }
  }, []);

 useEffect(() => {
    if (isLoading || isInitialPageLoading) return;

    let timeoutId: NodeJS.Timeout;
    const targetText = placeholderTexts[currentPlaceholderIndex];

    if (placeholderPhase === 'typing-in') {
      if (displayedPlaceholder.length < targetText.length) {
        timeoutId = setTimeout(() => {
          setDisplayedPlaceholder(targetText.substring(0, displayedPlaceholder.length + 1));
        }, typingSpeed);
      } else {
        setPlaceholderPhase('holding');
      }
    } else if (placeholderPhase === 'holding') {
      timeoutId = setTimeout(() => {
        setPlaceholderPhase('typing-out');
      }, holdDuration);
    } else if (placeholderPhase === 'typing-out') {
      if (displayedPlaceholder.length > 0) {
        timeoutId = setTimeout(() => {
          setDisplayedPlaceholder(prev => prev.substring(0, prev.length - 1));
        }, deletingSpeed);
      } else {
        setCurrentPlaceholderIndex((prevIndex) => (prevIndex + 1) % placeholderTexts.length);
        setPlaceholderPhase('typing-in'); 
      }
    }
    return () => clearTimeout(timeoutId);
  }, [currentPlaceholderIndex, displayedPlaceholder, placeholderPhase, placeholderTexts, holdDuration, typingSpeed, deletingSpeed, isLoading, isInitialPageLoading]);


  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(scrollToBottom, [messages]);

  useEffect(() => {
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto'; 
      const scrollHeight = textareaRef.current.scrollHeight;
      const maxHeight = 200; 
      textareaRef.current.style.height = `${Math.min(scrollHeight, maxHeight)}px`;
      if (scrollHeight > maxHeight) {
        textareaRef.current.style.overflowY = 'auto';
      } else {
        textareaRef.current.style.overflowY = 'hidden';
      }
    }
  }, [inputValue]);

  const handleEditUserMessage = (content: string) => {
    setInputValue(content);
    textareaRef.current?.focus();
    toast({ title: "Message copied to input for editing.", duration: 2500 });
  };

  const handleSendMessage = async (e?: FormEvent<HTMLFormElement>) => {
    if (e) e.preventDefault();
    const currentInput = inputValue.trim();
    if (!currentInput) return;

    if (typeof window !== 'undefined' && window.speechSynthesis && window.speechSynthesis.speaking) {
      window.speechSynthesis.cancel();
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: currentInput,
      timestamp: new Date(),
    };

    const historyForGenkit: MessageData[] = messages
      .filter(msg => typeof msg.content === 'string' && msg.content.trim() !== '') 
      .map(msg => ({
        role: msg.role === 'assistant' ? 'model' : msg.role,
        content: [{text: typeof msg.content === 'string' ? msg.content : "User provided complex content"}] 
      }));


    setMessages((prev) => [...prev, userMessage]);
    setInputValue("");
    setIsLoading(true);

    const assistantMessageId = (Date.now() + 1).toString();
    const loadingAssistantMessage: Message = {
      id: assistantMessageId,
      role: 'assistant',
      content: '', 
      isLoading: true,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, loadingAssistantMessage]);

    try {
      
      const response = await islamicScholarQuery({ query: currentInput, history: historyForGenkit });
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === assistantMessageId
            ? { ...msg, content: response.answer, isLoading: false, timestamp: new Date() }
            : msg
        )
      );
      
    } catch (error) {
      console.error("Error calling AI:", error);
      const errorText = "I apologize, but I encountered an error trying to process your request. Please try again later, Insha'Allah.";
      setMessages((prev) => prev.map(msg => msg.id === assistantMessageId ? {
        ...msg,
        content: errorText,
        isLoading: false,
        timestamp: new Date()
      } : msg));
      toast({
        title: "Error",
        description: "Failed to get response from AI. Please check your connection or try again.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
      if (textareaRef.current) { 
        textareaRef.current.style.height = 'auto';
        textareaRef.current.style.overflowY = 'hidden';
      }
    }
  };

  const handleDismissDisclaimer = () => {
    setShowDisclaimerDialog(false);
    localStorage.setItem('hikmah-disclaimer-dismissed', 'true');
  };

  const scrollToCard = (targetIndex: number) => {
    const targetCardElement = cardElementsRef.current[targetIndex];
    const container = cardsContainerRef.current;

    if (targetCardElement && container) {
      isProgrammaticScroll.current = true; 

      container.scrollTo({
        left: targetCardElement.offsetLeft,
        behavior: 'smooth',
      });
      
      const scrollFinishTimeout = 500; 
      setTimeout(() => {
        isProgrammaticScroll.current = false;
      }, scrollFinishTimeout);
    }
  };

  const handleNextCard = () => {
    const newIndex = (activeCardIndex + 1) % cardItems.length;
    setActiveCardIndex(newIndex);
    scrollToCard(newIndex);
  };

  const handlePrevCard = () => {
    const newIndex = (activeCardIndex - 1 + cardItems.length) % cardItems.length;
    setActiveCardIndex(newIndex);
    scrollToCard(newIndex);
  };
  
  if (isInitialPageLoading) {
    return <FullPageChatSkeleton />;
  }

  return (
    <div className="flex flex-col h-screen bg-background calligraphy-watermark-bg">
      <AppHeader />
      <ScrollArea className="flex-grow">
        <div style={{ paddingTop: `${headerHeight}px` }} className="relative">
          <div className="container mx-auto max-w-3xl px-4 pt-4 pb-4">
            
            <div className="relative">
              <div 
                ref={cardsContainerRef} 
                className="flex overflow-x-auto space-x-4 pb-3 mb-2 hide-scrollbar snap-x snap-mandatory"
                onScroll={(e) => {
                  if (isMobile && !isProgrammaticScroll.current) { 
                    const scrollLeft = e.currentTarget.scrollLeft;
                    const cardWidth = cardElementsRef.current[0]?.offsetWidth || e.currentTarget.offsetWidth;
                    if (cardWidth > 0) {
                        const newIndex = Math.round(scrollLeft / cardWidth);
                        if (newIndex !== activeCardIndex && newIndex >= 0 && newIndex < cardItems.length) {
                           setActiveCardIndex(newIndex);
                        }
                    }
                  }
                }}
              >
                <style jsx global>{`
                  .hide-scrollbar::-webkit-scrollbar {
                    display: none; /* Safari and Chrome */
                  }
                  .hide-scrollbar {
                    -ms-overflow-style: none;  /* IE and Edge */
                    scrollbar-width: none;  /* Firefox */
                  }
                `}</style>
                <div 
                    ref={el => cardElementsRef.current[0] = el}
                    className="snap-start flex-shrink-0 w-[calc(100%-2rem)] sm:w-[calc(50%-0.5rem)] md:w-[calc(50%-0.5rem)] lg:w-[calc(50%-0.5rem)] min-h-[180px] sm:min-h-[200px]"
                >
                  <DailyWisdom />
                </div>
                <div 
                    ref={el => cardElementsRef.current[1] = el}
                    className="snap-start flex-shrink-0 w-[calc(100%-2rem)] sm:w-[calc(50%-0.5rem)] md:w-[calc(50%-0.5rem)] lg:w-[calc(50%-0.5rem)] min-h-[180px] sm:min-h-[200px]"
                >
                  <DailyDuaCard />
                </div>
              </div>
              {isMobile && (
                <>
                  {activeCardIndex !== 0 && (
                    <Button 
                      onClick={handlePrevCard} 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-1/2 left-0 transform -translate-y-1/2 -translate-x-1 z-10 pointer-events-auto rounded-full bg-background/60 hover:bg-background/90 shadow-md h-8 w-8"
                      aria-label="Previous Card"
                    >
                      <ChevronLeft size={20} />
                    </Button>
                  )}
                  {activeCardIndex !== cardItems.length - 1 && (
                    <Button 
                      onClick={handleNextCard} 
                      variant="ghost" 
                      size="icon" 
                      className="absolute top-1/2 right-0 transform -translate-y-1/2 translate-x-1 z-10 pointer-events-auto rounded-full bg-background/60 hover:bg-background/90 shadow-md h-8 w-8"
                      aria-label="Next Card"
                    >
                      <ChevronRight size={20} />
                    </Button>
                  )}
                  <div className="flex justify-center mt-0 mb-2 space-x-2">
                    {cardItems.map((_, index) => (
                        <button
                            key={index}
                            onClick={() => { setActiveCardIndex(index); scrollToCard(index); }}
                            className={cn(
                                "h-2 w-2 rounded-full transition-all duration-300 ease-in-out",
                                activeCardIndex === index ? "bg-primary w-4" : "bg-muted hover:bg-muted-foreground/50"
                            )}
                            aria-label={`Go to card ${index + 1}`}
                        />
                    ))}
                  </div>
                </>
              )}
            </div>


            <div className="space-y-4">
              {messages.map((msg) => (
                <ChatMessage key={msg.id} message={msg} onEditMessage={handleEditUserMessage} />
              ))}
              <div ref={messagesEndRef} />
            </div>
          </div>
        </div>
      </ScrollArea>

      {mounted && showDisclaimerDialog && (
        <AlertDialog open={showDisclaimerDialog} onOpenChange={setShowDisclaimerDialog}>
          <AlertDialogContent className="max-w-md">
             <AlertDialogHeader className="flex flex-row items-center gap-3 pb-3">
                <AlertTriangle className="h-7 w-7 text-accent dark:neon-glow-accent" />
                <AlertDialogTitle className="font-headline text-accent dark:neon-glow-accent text-2xl m-0">
                    Important Disclaimer
                </AlertDialogTitle>
            </AlertDialogHeader>
            <div className="text-sm text-foreground/90 dark:text-foreground/80 space-y-2 pl-0 pt-2 max-h-[60vh] overflow-y-auto">
              <Disclaimer isPopupVersion={true} />
            </div>
            <AlertDialogFooter className="mt-4">
              <AlertDialogAction
                onClick={handleDismissDisclaimer}
                className="bg-accent hover:bg-accent/90 text-accent-foreground dark:neon-glow-accent"
              >
                I Understand & Agree
              </AlertDialogAction>
            </AlertDialogFooter>
          </AlertDialogContent>
        </AlertDialog>
      )}

      <div className="border-t border-border/70 dark:border-border/50 bg-card dark:bg-background/80 p-3 shadow-top-lg rounded-tl-[32px] rounded-tr-[32px]">
        <form onSubmit={handleSendMessage} className="container mx-auto max-w-3xl flex items-end gap-2">
          <Textarea
            ref={textareaRef}
            value={inputValue}
            onChange={(e) => setInputValue(e.target.value)}
            placeholder={displayedPlaceholder}
            className="flex-grow resize-none min-h-[52px] max-h-[200px] text-base p-3.5 rounded-2xl shadow-inner focus:ring-2 focus:ring-primary dark:focus:ring-primary bg-white dark:bg-input placeholder:text-muted-foreground border-transparent focus:border-transparent transition-all duration-150 ease-in-out leading-tight"
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSendMessage();
              }
            }}
            rows={1}
            disabled={isLoading}
          />
          <div className="flex flex-col gap-1.5">
            <Button
              type="submit"
              disabled={isLoading || !inputValue.trim()}
              className={cn(
                "h-[52px] w-[52px] p-0 shadow-md hover:shadow-lg transition-all duration-150 ease-in-out",
                "bg-primary hover:bg-primary/90 text-primary-foreground",
                "dark:neon-glow-primary",
                "flex items-center justify-center rounded-full focus-visible:ring-2 focus-visible:ring-ring"
              )}
              aria-label="Send Question"
            >
              <Send size={20} /> 
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}

