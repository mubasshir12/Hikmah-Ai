
"use client";

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpenText, AlertCircle } from 'lucide-react';
import { getShortDailyDua } from '@/ai/flows/short-daily-dua-flow';
import type { ShortDailyDuaOutput } from '@/ai/schemas/short-daily-dua-schemas';

const DuaCardSkeleton = () => {
  return (
    <Card className="w-full h-full shadow-lg border-primary/50 bg-gradient-to-br from-background to-muted/30 dark:from-background dark:to-muted/20 flex flex-col">
      <CardHeader className="pb-3 pt-4">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary dark:text-primary dark:neon-glow-primary">
            <BookOpenText size={20} />
            <CardTitle className="font-headline text-xl">Daily Dua</CardTitle>
            </div>
        </div>
      </CardHeader>
      <CardContent className="pb-4 flex-grow flex flex-col items-center justify-center">
        <div className="w-full space-y-1 text-center mb-2">
            <Skeleton className="h-4 w-4/5 mx-auto rounded-md bg-muted/40 dark:bg-muted/20" />
            <Skeleton className="h-4 w-3/5 mx-auto rounded-md bg-muted/40 dark:bg-muted/20" />
            <Skeleton className="h-4 w-2/5 mx-auto rounded-md bg-muted/40 dark:bg-muted/20" />
        </div>
        <Skeleton className="h-3 w-1/3 ml-auto mt-1 rounded-md bg-muted/30 dark:bg-muted/15" />
      </CardContent>
    </Card>
  );
};

const LOCAL_STORAGE_KEY = 'hikmahDailyShortDuaV2'; // Incremented version due to schema change

const getTodaysDateString = () => {
  return new Date().toISOString().split('T')[0]; // YYYY-MM-DD
};

export function DailyDuaCard() {
  const [dua, setDua] = useState<ShortDailyDuaOutput | null>(null);
  const [isLoadingDua, setIsLoadingDua] = useState(true);
  const [fetchError, setFetchError] = useState<string | null>(null);

  const fetchAndStoreDua = async () => {
    setIsLoadingDua(true);
    setDua(null);
    setFetchError(null);

    try {
      const fetchedDua = await getShortDailyDua();
      if (fetchedDua && typeof fetchedDua.arabicText === 'string' && fetchedDua.arabicText.trim() !== "") {
        setDua(fetchedDua);
        localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({ dua: fetchedDua, date: getTodaysDateString() }));
      } else {
        console.warn("Fetched Daily Dua has missing, empty or invalid arabicText:", fetchedDua);
        setFetchError("Received an invalid Dua. Showing a default Dua.");
        setDua({ arabicText: "رَبِّ اشْرَحْ لِي صَدْرِي\nوَيَسِّرْ لِي أَمْرِي", duaSource: "Quran" }); 
      }
    } catch (error: any) {
      console.error("Failed to fetch daily short dua:", error);
      const errorMessage = error.message || "An unknown error occurred.";
      setFetchError(`Failed to load Dua. ${errorMessage}. Showing a default Dua.`);
      setDua({ arabicText: "اللَّهُمَّ إِنِّي أَسْأَلُكَ عِلْمًا نَافِعًا\nوَرِزْقًا طَيِّبًا\nوَعَمَلاً مُتَقَبَّلاً", duaSource: "Sunnah" }); 
    } finally {
      setIsLoadingDua(false);
    }
  };

  useEffect(() => {
    const storedDataString = localStorage.getItem(LOCAL_STORAGE_KEY);
    const today = getTodaysDateString();

    if (storedDataString) {
      try {
        const parsedData = JSON.parse(storedDataString);
        if (parsedData.date === today && parsedData.dua && parsedData.dua.arabicText) {
          setDua(parsedData.dua);
          setIsLoadingDua(false);
          return; 
        }
      } catch (e) {
        console.error("Error parsing stored daily dua:", e);
        localStorage.removeItem(LOCAL_STORAGE_KEY); 
      }
    }
    fetchAndStoreDua();
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []); 


  if (isLoadingDua) {
    return <DuaCardSkeleton />;
  }

  if (fetchError && !dua?.arabicText) { 
    return (
      <Card className="w-full h-full shadow-lg border-destructive/50 flex flex-col">
        <CardHeader className="pb-2 pt-4">
          <div className="flex items-center gap-2 text-destructive">
            <AlertCircle size={20} />
            <CardTitle className="font-headline text-xl">Daily Dua Error</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="pb-4 flex-grow flex flex-col items-center justify-center">
          <p className="text-center text-sm">{fetchError}</p>
        </CardContent>
      </Card>
    );
  }
  
  if (!dua?.arabicText) {
     return (
      <Card className="w-full h-full shadow-lg flex flex-col">
        <CardHeader className="pb-2 pt-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary dark:text-primary dark:neon-glow-primary">
                <BookOpenText size={20} />
                <CardTitle className="font-headline text-xl">Daily Dua</CardTitle>
            </div>
          </div>
        </CardHeader>
        <CardContent className="pb-4 flex-grow flex flex-col items-center justify-center">
          <div className="text-center font-arabic text-lg md:text-xl leading-normal py-1 px-1 text-foreground dark:text-foreground/90 whitespace-pre-wrap break-words">
            رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً
          </div>
          <p className="text-right text-xs text-muted-foreground dark:text-muted-foreground/70 mt-2 w-full px-2">- Quran</p>
        </CardContent>
      </Card>
    );
  }


  return (
    <Card className="w-full h-full shadow-lg border-primary/50 bg-gradient-to-br from-background to-muted/30 dark:from-background dark:to-muted/20 flex flex-col">
      <CardHeader className="pb-2 pt-4">
        <div className="flex items-center justify-between">
            <div className="flex items-center gap-2 text-primary dark:text-primary dark:neon-glow-primary">
                <BookOpenText size={20} />
                <CardTitle className="font-headline text-xl">Daily Dua</CardTitle>
            </div>
        </div>
      </CardHeader>
      <CardContent className="pb-4 flex-grow flex flex-col justify-center">
        {dua.arabicText && (
          <div className="text-center font-arabic text-lg md:text-xl leading-normal py-1 px-2 text-foreground dark:text-foreground/90 whitespace-pre-wrap break-words">
            {dua.arabicText}
          </div>
        )}
        {dua.duaSource && (
           <p className="text-right text-xs text-muted-foreground dark:text-muted-foreground/70 mt-auto pt-2 w-full px-2">
            - {dua.duaSource}
           </p>
        )}
      </CardContent>
    </Card>
  );
}

