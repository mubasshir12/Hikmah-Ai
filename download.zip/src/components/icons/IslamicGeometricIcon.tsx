import type { SVGProps } from 'react';

export function IslamicGeometricIcon(props: SVGProps<SVGSVGElement>) {
  return (
    <svg 
      xmlns="http://www.w3.org/2000/svg" 
      viewBox="0 0 100 100" 
      fill="currentColor"
      width="24" 
      height="24" 
      {...props}
    >
      <path d="M50 5L57.36 27.64L80.9 27.64L61.77 42.36L69.12 65L50 50.27L30.88 65L38.23 42.36L19.1 27.64L42.64 27.64Z" />
      <path d="M50 15L55.22 33.51L74.39 33.51L59.58 45.49L64.8 64L50 52.02L35.2 64L40.42 45.49L25.61 33.51L44.78 33.51Z" opacity="0.6"/>
    </svg>
  );
}
