
'use server';
/**
 * @fileOverview This file defines a Genkit flow for providing a very short daily Dua in Arabic.
 *
 * - getShortDailyDua -  A function that returns a short daily Dua.
 * - ShortDailyDuaOutput - The output type for the getShortDailyDua function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { ShortDailyDuaOutputSchema, type ShortDailyDuaOutput } from '@/ai/schemas/short-daily-dua-schemas';

export async function getShortDailyDua(): Promise<ShortDailyDuaOutput> {
  return shortDailyDuaFlow({});
}

const prompt = ai.definePrompt({
  name: 'shortDailyDuaPrompt',
  input: {schema: z.object({}) },
  output: {schema: ShortDailyDuaOutputSchema},
  prompt: `You are Hikmah AI, an Islamic AI assistant.
Your task is to provide one uplifting Dua in Arabic and its source, suitable for a small display card.
The Dua MUST be concise, around 3 to 5 short lines maximum. Examples: "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي" or "اللَّهُمَّ إِنِّي أَسْأَلُكَ الْهُدَى وَالتُّقَى وَالْعَفَافَ وَالْغِنَى".
Each time you are asked, try to provide a different one from a diverse set of options.
Populate both 'arabicText' and 'duaSource' fields. The 'duaSource' should be a brief reference like "Quran", "Hadith", "Sunnah", or a specific Surah/Hadith reference if very common and short. If the source is a general supplication not tied to a specific text, you can use "Islamic Supplication".

Provide one such Dua and its source now.`,
});

const shortDailyDuaFlow = ai.defineFlow(
  {
    name: 'shortDailyDuaFlow',
    inputSchema: z.object({}),
    outputSchema: ShortDailyDuaOutputSchema,
  },
  async () => {
    const {output} = await prompt({});
    return output!;
  }
);

