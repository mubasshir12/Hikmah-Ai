
'use server';
/**
 * @fileOverview A Genkit flow to generate a daily piece of wisdom.
 * - getDailyWisdom - Fetches a daily wisdom quote.
 * - DailyWisdomOutput - The return type.
 */
import {ai} from '@/ai/genkit';
import {z} from 'genkit';
import { DailyWisdomOutputSchema, type DailyWisdomOutput } from '@/ai/schemas/daily-wisdom-schemas';

export async function getDailyWisdom(): Promise<DailyWisdomOutput> {
  // This function now acts as the direct caller of the flow for simplicity in client-side usage
  return dailyWisdomFlow({}); 
}

const prompt = ai.definePrompt({
  name: 'dailyWisdomPrompt',
  input: { schema: z.object({}) }, // Define empty input schema if no specific input is needed
  output: {schema: DailyWisdomOutputSchema},
  prompt: `You are Hikmah AI, an AI assistant. Your task is to provide a short, inspiring piece of wisdom, a positive affirmation, or a concise quote suitable for daily reflection.
The content should be universally uplifting or align with general positive Islamic values and the teachings of the Hanafi Barelvi Maslak.
If it's a direct Quranic verse or Hadith, please provide the reference as the source. Otherwise, attribute it if known (e.g. "Imam Ahmed Raza Khan"), or use "Islamic Wisdom" or "Anonymous" if the specific source is general or unknown.
Keep the wisdom text to one or two impactful sentences.

Generate one such piece of wisdom now.`,
});

const dailyWisdomFlow = ai.defineFlow(
  {
    name: 'dailyWisdomFlow',
    inputSchema: z.object({}), // Define empty input schema
    outputSchema: DailyWisdomOutputSchema,
  },
  async () => { // No input parameter 'input' needed here if inputSchema is empty
    const {output} = await prompt({});
    return output!;
  }
);
