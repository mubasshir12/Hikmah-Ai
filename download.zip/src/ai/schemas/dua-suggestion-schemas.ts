
import {z} from 'genkit';
import { MessageDataSchema } from './common-genkit-schemas';

export const DuaSuggestionInputSchema = z.object({
  userInput: z.string().describe('The user input expressing a problem, need, or situation for which a Dua is sought. This input can be in English, Urdu, Hindi, or Hinglish.'),
  history: z.array(MessageDataSchema).optional().describe('The history of the conversation.'),
});
export type DuaSuggestionInput = z.infer<typeof DuaSuggestionInputSchema>;

export const DuaSuggestionOutputSchema = z.object({
  arabicText: z.string().describe('The Dua in its original Arabic script. This field should only contain the Arabic text and be accurate. Use newline characters (\\n) to structure longer Duas into readable lines, similar to Quranic verses.'),
  transliteration: z.string().describe('A precise and easy-to-follow English transliteration of the Arabic text, adhering to standard transliteration rules.'),
  englishMeaning: z.string().describe("A clear, accurate, and detailed translation of the Dua's meaning in English."),
  urduKanzulImanTranslation: z.string().optional().describe('Urdu translation of the Dua. For Quranic verses, this MUST be based on Kanzul Iman. For Hadith Duas, use a recognized Sunni Barelvi scholarly translation. Include the source of translation (e.g., "Translation: Kanzul Iman") within the text if it is a direct quote. Ensure the text is in Urdu script.'),
  languageOfUrduTranslation: z.string().optional().describe('Should be "Urdu" if urduKanzulImanTranslation is provided.'),
  source: z
    .string()
    .describe(
      'The specific and authentic source of the Dua, recognized within the Hanafi Barelvi tradition (e.g., Quran, Surah Al-Baqarah, 2:201), or Hadith collection and reference (e.g., Sahih Al-Bukhari, Hadith 6304). Be as precise as possible.'
    ),
  contextOrBenefit: z.string().optional().describe('A brief explanation of the context in which this Dua might be recited or its spiritual benefits, based on reliable Islamic narrations or scholarly explanations accepted within the Hanafi Barelvi Maslak. If unknown or not applicable within this Maslak, this can be omitted. This explanation should be in the language of the user query (English, Urdu, Hindi, or Hinglish).'),
  languageOfExplanation: z.string().optional().describe('The language used for the contextOrBenefit field, if provided (e.g., "English", "Urdu", "Hindi", "Hinglish").')
});
export type DuaSuggestionOutput = z.infer<typeof DuaSuggestionOutputSchema>;

