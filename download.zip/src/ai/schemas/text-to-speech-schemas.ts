
import { z } from 'zod';

export const SynthesizeSpeechInputSchema = z.object({
  text: z.string().min(1).describe('The text to synthesize into speech.'),
  // voiceId: z.string().optional().describe('Optional AssemblyAI voice ID.'), // Using AssemblyAI's default voice for simplicity
});
export type SynthesizeSpeechInput = z.infer<typeof SynthesizeSpeechInputSchema>;

export const SynthesizeSpeechOutputSchema = z.object({
  audioUrl: z.string().url().optional().describe('The URL of the generated audio file.'),
  error: z.string().optional().describe('Error message if synthesis failed.'),
});
export type SynthesizeSpeechOutput = z.infer<typeof SynthesizeSpeechOutputSchema>;
