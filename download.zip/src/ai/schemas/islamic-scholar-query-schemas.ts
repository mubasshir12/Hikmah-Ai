
import {z} from 'genkit';
import { MessageDataSchema } from './common-genkit-schemas';

export const IslamicScholarQueryInputSchema = z.object({
  query: z.string().describe('The question about an Islamic topic.'),
  history: z.array(MessageDataSchema).optional().describe('The history of the conversation.'),
});
export type IslamicScholarQueryInput = z.infer<typeof IslamicScholarQueryInputSchema>;

export const IslamicScholarQueryOutputSchema = z.object({
  answer: z.string().describe('The detailed, comprehensive, and structured answer to the question, formatted using Markdown. The answer MUST BE EXCLUSIVELY AND INHERENTLY from the perspective of the Hanafi school of Fiqh as understood and practiced by the Sunni Barelvi Maslak. The AI will draw from authentic sources recognized within this tradition (Quran, Sunnah, and works of esteemed Hanafi Barelvi scholars, especially Aala Hazrat Imam Ahmed Raza Khan Barelvi). It should respond in the language of the user query if it is English, Urdu, Hindi, or Hinglish.'),
});
export type IslamicScholarQueryOutput = z.infer<typeof IslamicScholarQueryOutputSchema>;
