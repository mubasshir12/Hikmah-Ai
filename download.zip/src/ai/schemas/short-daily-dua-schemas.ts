
import {z} from 'genkit';

export const ShortDailyDuaOutputSchema = z.object({
  arabicText: z.string().describe('A concise Dua in Arabic, suitable for a small display card (around 3-5 short lines maximum).'),
  duaSource: z.string().optional().describe('The source of the Dua (e.g., "Quran", "Hadith", "Sunnah", or a short specific reference if common).'),
});
export type ShortDailyDuaOutput = z.infer<typeof ShortDailyDuaOutputSchema>;

