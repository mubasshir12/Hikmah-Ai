
import {z} from 'genkit';

export const DailyWisdomOutputSchema = z.object({
  wisdomText: z.string().describe('A short, inspiring piece of wisdom or a quote.'),
  wisdomSource: z.string().describe('The source of the wisdom or quote (e.g., "Hadith", "Anonymous", "Scholar X"). If it is a direct Quranic verse or Hadith, mention the reference.'),
});
export type DailyWisdomOutput = z.infer<typeof DailyWisdomOutputSchema>;
