
import {z} from 'genkit';

// Define Zod schemas for the structure of MessageData and its parts
export const PartDataSchema = z.object({
  text: z.string().optional(),
  media: z.object({
    url: z.string(),
    contentType: z.string().optional()
  }).optional(),
});

export const MessageDataSchema = z.object({
  role: z.enum(['user', 'model', 'system', 'tool']),
  content: z.array(PartDataSchema),
});
