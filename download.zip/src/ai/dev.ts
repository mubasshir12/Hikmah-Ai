
import { config } from 'dotenv';
config();

import '@/ai/flows/islamic-scholar-query.ts';
import '@/ai/flows/dua-suggestion.ts';
import '@/ai/flows/daily-wisdom-flow.ts';
import '@/ai/flows/general-dua-flow.ts'; 
import '@/ai/flows/short-daily-dua-flow.ts'; // Added new flow

