
// import { initializeApp, getApps, FirebaseApp } from 'firebase/app';
// import { getAuth, GoogleAuthProvider } from 'firebase/auth';
// // import { getFirestore } from 'firebase/firestore'; // Uncomment if you use Firestore

// const firebaseConfig = {
//   apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
//   authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
//   projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
//   storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
//   messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
//   appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
//   measurementId: process.env.NEXT_PUBLIC_FIREBASE_MEASUREMENT_ID,
// };

// let firebaseApp: FirebaseApp | undefined = undefined;
// let auth: any = undefined; // Using any to avoid build errors if Firebase is not configured
// let googleAuthProvider: any = undefined;

// if (process.env.NEXT_PUBLIC_FIREBASE_API_KEY && getApps().length === 0) {
//   try {
//     firebaseApp = initializeApp(firebaseConfig);
//     auth = getAuth(firebaseApp);
//     googleAuthProvider = new GoogleAuthProvider();
//   } catch (error) {
//     console.error("Firebase initialization error:", error);
//     // Set to undefined or handle as per your app's error strategy if init fails
//     firebaseApp = undefined;
//     auth = undefined;
//     googleAuthProvider = undefined;
//   }
// } else if (getApps().length > 0) {
//   firebaseApp = getApps()[0];
//   auth = getAuth(firebaseApp);
//   googleAuthProvider = new GoogleAuthProvider();
// } else {
//   console.warn("Firebase not configured. NEXT_PUBLIC_FIREBASE_API_KEY is missing or Firebase already initialized elsewhere incorrectly.");
// }


// // const db = getFirestore(firebaseApp); // Uncomment if you use Firestore

// export { firebaseApp, auth, googleAuthProvider /*, db */ };
